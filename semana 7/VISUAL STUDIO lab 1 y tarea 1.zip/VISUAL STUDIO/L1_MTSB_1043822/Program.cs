﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_MTSB_1043822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo soy Teresa Solares");
         

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy Teresa Solares");
          
            /*La diferencia entre Write y WriteLine es que en Write coloca el mensaje en una linea mientras que WriteLine lo agrega linea por linea */
            Console.Write("Hola Mundo");
            Console.Write("soy Teresa Solares");

            Console.WriteLine("Ingrese su nombre:  ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy " + Nombre);

            Console.Write("Hola Mundo ");
            Console.Write("soy " + Nombre);

            Console.ReadKey();
        }
}
}
