﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_MTSB_1043822_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int suma = 0;
            int promedio = 0;
            Random r = new Random();

            int[,] m1 = new int[4, 5];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    m1[i, j] = r.Next(100);
                    suma= suma + m1[i, j];
                }
            }
            promedio = suma/m1.Length;
            Console.WriteLine("La suma de la matriz 1 es: " + suma);
            Console.WriteLine("El promedio de la matriz 1 es: " + promedio);

            int[,] m2 = new int[4, 5];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    m2[i, j] = r.Next(100);
                    
                }
            }

            int[,] m3 = new int[4, 5];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    m3[i,j] = m1[i,j] + m2[i,j];
                    Console.Write(m3[i, j] + "\t");

                }
                Console.WriteLine();

                
            }
            Console.ReadKey();

        }
    }
}
