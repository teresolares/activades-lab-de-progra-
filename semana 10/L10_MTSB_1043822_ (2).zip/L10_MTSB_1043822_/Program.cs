﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_MTSB_1043822_
{
    class Program
    {
        static void Main(string[] args)
        {

            string usuario;
            string contraseña;
            int intentos = 0;
            int veces = 0;
            bool vof = false;
            while (veces < 3)
            {
                Console.WriteLine("Ingrese su usuario");
                usuario = Console.ReadLine();
                Console.WriteLine("Ingrese su contraseña");
                contraseña = Console.ReadLine();
                vof = Login(usuario, contraseña);
                if (vof == true)
                {
                    veces = 3;
                    Console.WriteLine("Bienvenido, usuario y contraseña correctos");
                }
                else
                {
                    Console.WriteLine("No ingreso correcatmente el usuario y contraseña, oportunidad:" + (veces +1));
                    intentos++;
                    veces++;
                }
                if (intentos == 3)
                {
                    Console.WriteLine("Se han acabado los intentos para acceder");
                }
                Console.ReadKey();
            }


        }
        static bool Login(string usuario, string contraseña)

        {

            if (usuario == "usuario1" && contraseña == "asdasd")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}