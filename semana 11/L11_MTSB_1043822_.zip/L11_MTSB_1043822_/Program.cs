﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_MTSB_1043822_
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double[] seccion1 = new double[5];
            double[] seccion2 = new double[6];
            int aprobados = 0;
            int desaprobados = 0;
            int aprobados2 = 0;
            int desaprobados2 = 0;
            double porcentajeaprobados1 = 0;
            double porcentajedesaprobados1 = 0;
            double porcentajeaprobados2 = 0;
            double porcentajedesaprobados2 = 0;
            double porcentajeaprobadosambas = 0;
            double porcentajedesaprobadosambas = 0;
            double suma1 = 0;
            double suma2 = 0;
            double promedio = 0;
            double promedio2 = 0;
            double promediototal = 0;
            double promm90 = 0;
            double promd75 = 0;
            double promm902 = 0;
            double promd752 = 0;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese la nota del estudiante  " + (i + 1) + "de la sección1");
                seccion1[i] = double.Parse(Console.ReadLine());
                suma1 = suma1 + seccion1[i];
            }
            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Ingrese la nota del estudiante" + (i + 1) + "de la sección2");
                seccion2[i] = double.Parse(Console.ReadLine());
                suma2 = suma2 + seccion2[i];
                
            }

            for (int i = 0; i < 5; i++)
            {
                if (seccion1[i] >= 65)
                {
                    aprobados++;
                } else
                {
                    desaprobados++;
                }

                if (seccion1[i] > 90)
                {
                    promm90++;  
                } 
                if (seccion1[i] <75)
                {
                    promd75++;  
                }


            }
            porcentajeaprobados1 = (aprobados * 100) / seccion1.Length;
            Console.WriteLine("El porcentaje de aprobados de la sección 1 es:" + porcentajeaprobados1);

            porcentajedesaprobados1 = (desaprobados * 100) / seccion1.Length;
            Console.WriteLine("El porcentaje de desaprobados de la sección 1 es:" + porcentajedesaprobados1);

            for (int i = 0; i < 6; i++)
            {
                if (seccion2[i] >= 65)
                {
                    aprobados2++;
                }
                else
                {
                    desaprobados2++;
                }

                if (seccion2[i] > 90)
                {
                    promm902++;
                }
                if (seccion2[i] <75)
                {
                    promd752++;
                }

               

            }

            porcentajeaprobados2 = (aprobados2 * 100) / seccion2.Length;
            Console.WriteLine("El porcentaje de aprobados de la sección 2 es:" + porcentajeaprobados2);

            porcentajedesaprobados2 = (desaprobados2 * 100) / seccion2.Length;
            Console.WriteLine("El porcentaje de desaprobados de la sección 2 es:" + porcentajedesaprobados2);

            porcentajeaprobadosambas = ((aprobados + aprobados2) * 100) / (seccion1.Length + seccion2.Length);
            Console.WriteLine("El porcentaje de aprobados de ambas secciónes son:" + porcentajeaprobadosambas);

            porcentajedesaprobadosambas =((desaprobados+desaprobados2)*100)/ (seccion1.Length + seccion2.Length);
            Console.WriteLine("El porcentaje de desaprobados de ambas secciones son: " + porcentajedesaprobadosambas);

            promedio = suma1 / seccion1.Length;
            Console.WriteLine("El promedio de notas de la sección 1 es: " + promedio);

            promedio2 = suma2 / seccion2.Length;
            Console.WriteLine("El promedio de notas de la sección 2 es: " + promedio2);

            promediototal =(suma1+suma2)/(seccion1.Length+seccion2.Length);
            Console.WriteLine("El promedio total de notas es de: " + promediototal);


            Console.WriteLine("La cantidad de estudiantes encima de 90 son: " + (promm90 + promm902));
            Console.WriteLine("La cantidad de estudiantes debajo de 75 son: " + (promd752 + promd75));


            Console.ReadKey();

        }
    }
}

