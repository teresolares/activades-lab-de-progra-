﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_MTSB_1043822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int modelo = 0;
            double precio = 0.00;
            string marca = "";
            bool disponible = false;
            string rdisponible = "";
            double tipodecambiodedolar = 7.50;
            double descuentoaplicado = 0.00;

            Console.WriteLine("ingrese modelo del automovil");
            modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("ingrese precio del automovil");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("ingrese marca del automovil");
            marca = Console.ReadLine();

            Console.WriteLine(" ingrese disponibilidad");
            rdisponible = Console.ReadLine();

            if (rdisponible == "disponible")
            {
                disponible = true;
            }

            Console.WriteLine("ingrese el descuento del automovil");
            descuentoaplicado = double.Parse(Console.ReadLine());


            mostrarinformacion(modelo, precio, rdisponible, marca, tipodecambiodedolar, descuentoaplicado);

            Console.ReadKey();

        }

        static void mostrarinformacion(int modelo, double precio, string marca, string rdisponible,
            double tipodecambiodedolar, double descuentoaplicado)
        {
            double resultadoquetzales = precio - precio * (descuentoaplicado / 100);
            double resultadocambio = resultadoquetzales / tipodecambiodedolar;


            Console.WriteLine("Marca " + marca + ". Modelo " + modelo + ". Precio " + resultadoquetzales + ". Precio en dolares " + resultadocambio + ". Mostrar disponibilidad " + rdisponible);
        }
    }
}
