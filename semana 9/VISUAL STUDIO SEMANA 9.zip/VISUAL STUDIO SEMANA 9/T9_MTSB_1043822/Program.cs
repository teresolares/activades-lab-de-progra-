﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_MTSB_1043822
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int modelo = 0;
            double precio = 0.00;
            string marca = "";
            double IVA = 0.12;

            Console.WriteLine("Ingrese el modelo de la motocicleta");
            modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el precio de la motocicleta");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la marca de la motocicleta");
            marca = Console.ReadLine();

           
            mostrarinformacion(modelo, precio, marca, IVA);

            Console.ReadKey();
        }
        static void mostrarinformacion(int modelo, double precio, string marca, double IVA)
        {
            double ivaCALCULADO = precio + (precio * 0.12);
            double elIVA = (precio * 0.12);

            Console.WriteLine("Marca " + marca + ". Modelo " + modelo + ". Precio " + precio + ". Precio con IVA incluido " + ivaCALCULADO + ". Solo IVA " + elIVA);
        }
    }
}
