﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T8_1043822_MTSB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string binario = "";
            int num = int.Parse(textBox1.Text);
            while (num > 0)
            {
                binario = (num % 2) + binario;
                num = (int)num / 2;

            }
            label2.Text = binario;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string hexa = "";
            int num = int.Parse(textBox1.Text);
            while (num > 0)
            {
                switch (num % 16)
                {
                    case 10: hexa = "A" + hexa;
                    break;
                    case 11: hexa = "B" + hexa;
                    break;
                    case 12: hexa = "C" + hexa;
                    break;
                    case 13: hexa = "D" + hexa;
                    break;
                    case 14: hexa = "E" + hexa;
                    break;
                    case 15: hexa = "F" + hexa;
                    break;

                    default: 
                        hexa = (num % 16) + hexa; 
                        break;
                }

                num = (int)num / 16;
            }
            label3.Text = hexa;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
