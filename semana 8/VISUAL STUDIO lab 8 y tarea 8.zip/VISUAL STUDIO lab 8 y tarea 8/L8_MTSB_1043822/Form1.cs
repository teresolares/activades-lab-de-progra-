﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_MTSB_1043822
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int respuesta = comboBox1.SelectedIndex;
            switch (respuesta)
            {
                case 0:tabControl1.SelectTab(respuesta);
                    break;
                case 1: tabControl1.SelectTab(respuesta);
                    break;
                case 2: tabControl1.SelectTab(respuesta);
                    break;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int suma = 0, cuenta = 0;
            do
            {
                suma += cuenta;
                cuenta++;

            } while (cuenta <= int.Parse(textBox1.Text));
            label2.Text = suma.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string respuesta = "";
            int i, j;
            for (i=1;i<=10;i++)
            {
                if (i==1)
                {
                    respuesta += "\t";
                    for (j = 1; j <= 10; j++)
                        respuesta += j + "\t";
                    respuesta += "\n";
         
                }
                respuesta += i + "\t";
                for (j=1; j<=10; j++)
                {
                    respuesta += (i*j) + "\t";
                }
                respuesta += "\n";
            }
            richTextBox1.Text = respuesta;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int contar, suma = 0, numero = int.Parse(textBox2.Text);
            for (contar = 1; contar < numero; contar++)
            {
                if (numero % contar == 0)
                    suma += contar;
            }
            if (suma == numero)
                label5.Text = "número perfecto";
            else
                label5.Text = "número no perfecto";
        }
    }
}
